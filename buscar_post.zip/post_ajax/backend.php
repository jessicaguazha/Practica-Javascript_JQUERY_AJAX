<?php
    if(isset($_POST)){
        echo "Me envìas el usuario: " . $_POST['username'];
        echo " y la contraseña: " . $_POST['password'];
    }
?>
