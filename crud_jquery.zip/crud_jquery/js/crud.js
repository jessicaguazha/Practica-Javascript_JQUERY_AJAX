$(document).ready(function(){
    obtenerTareas();
        let modificar = false;
        function obtenerTareas(){
        $.ajax({
            URL: 'listar.php',
            type: "GET",
            success: function(tareas){
                let tasks = JSON.parse(tareas);
                let template = '';
                tasks.forEach(task => {
                    template += `
                    <tr taskId = "${task.id}">
                        <td><a href="#" class="task-item">${task.id}</a></td>
                        <td>${task.name}</td>
                        <td>${task.description}</td>
                        <td><button class="btn btn-danger"> ELIMINAR </button></td>
                    </tr>
                    `
                });
                $('#tasks').html(template);
            }
        });
    }

    $('#task.form').submit(e=>{
        const datos = {
            name: $('#name').val(),
            description: $('#description').val(),
            id: $('#id').val(),
        }
        const url = modificar === false ? 'insertar.php' : 'modificar.php';
        $.post(url, datos, (response) =>{
            obtenerTareas();
        });
    });

    $(document).on('click','.task-item', (e)=>{
        const elemento = $(this)[0].activeElement.parentElement.parseElement;
        const id = $(elemento).attr('taskId');
        console.log(id);
    });
});